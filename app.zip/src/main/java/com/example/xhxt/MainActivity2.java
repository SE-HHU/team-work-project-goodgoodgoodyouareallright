package com.example.xhxt;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity2 extends AppCompatActivity {
    int  i=1;
    int wrong =0;
    int right=0;
    int t=1;
    int regular=-1;
    int second =10;
    String  [] args =new String[10000];
    String  [] args1 =new String[10000];
    TextView time;
    Timer timer=null;
    TimerTask task=null;
    boolean sss=true;


    private void initView(int s) {
        time= findViewById(R.id.time_1);
        startTime(s);

    }
    private Handler mHandler = new Handler() {
        public void handleMessage(Message msg) {
            time.setText("倒计时:"+msg.arg1 + "s");

            startTime(second);
            if(second==0&&sss==true)
            {
                sss=false;
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity2.this);
                builder.setMessage("时间到了，请点击交卷");
                builder.setPositiveButton("确定", null).show();
            }
        };
    };
    public void startTime(int s) {
        //s=second;
        second=s;
        timer = new Timer();
        task = new TimerTask() {

            @Override
            public void run() {
                if (second > 0) {   //加入判断不能小于0
                    second--;
                    Message message = mHandler.obtainMessage();
                    message.arg1 = second;
                    mHandler.sendMessage(message);

                }
            }
        };
        timer.schedule(task, 1000);

    }




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        ActionBar actionBar = getSupportActionBar();
        if (actionBar!=null){
            actionBar.hide();
        }

        Intent intent =getIntent();
        int number = intent.getIntExtra("number",1);
        int time = intent.getIntExtra("time",1);
        int grade = intent.getIntExtra("grade",1);
        int spinner=intent.getIntExtra("spinner",1);
        int timeend=time;
TextView time2 = (TextView)findViewById(R.id.time_1);
time2.setText("倒计时："+time+"s");
        initView(time);

        TextView textView1 = (TextView) findViewById(R.id.textview_1);
        TextView textView2 = (TextView) findViewById(R.id.textview_2);
        TextView textView3 = (TextView) findViewById(R.id.textview_3);
        TextView textView4 = (TextView) findViewById(R.id.textview_4);
        TextView textView5 = (TextView) findViewById(R.id.textview_5);

        ImageButton imageButton1=(ImageButton) findViewById(R.id.imagebutton_1);
        ImageButton imageButton2=(ImageButton) findViewById(R.id.imagebutton_2);
        ImageButton imageButton3=(ImageButton) findViewById(R.id.imagebutton_3);
        ImageButton imageButton4=(ImageButton) findViewById(R.id.imagebutton_4);
        ImageButton imageButton5=(ImageButton) findViewById(R.id.imagebutton_5);


        int numRange=100 ;
        if(spinner==1) numRange=10;
        if(spinner==2) numRange=50;
        if(spinner==3) numRange=60;
        if(spinner==4) numRange=30;
        if(spinner==5) numRange=50;
        if(spinner==6) numRange=10;



        int finalNumRange = numRange;

       ImageButton button = (ImageButton)  findViewById(R.id.button_11);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                EditText editText1=(EditText) findViewById(R.id.edittext_1);
                String ans1 = editText1.getText().toString();
                String rightAns1 = new StackCalculate(finalNumRange).getResult(textView1.getText().toString());
                if(ans1.equals(rightAns1))
                    right++;
                if(!ans1.equals(rightAns1)){
                    wrong++;
                    args[t]=(String) textView1.getText();
                    t++;
                    StoreQuestion.addToWrongFile(MainActivity2.this,textView1.getText().toString());
                }

                EditText editText2=(EditText) findViewById(R.id.edittext_2);
                String ans2 = editText2.getText().toString();
                String rightAns2 = new StackCalculate(finalNumRange).getResult(textView2.getText().toString());
                if(ans2.equals(rightAns2))
                    right++;
                if(!ans2.equals(rightAns2)){
                    wrong++;
                    args[t]=(String) textView2.getText();
                    t++;
                    StoreQuestion.addToWrongFile(MainActivity2.this,textView2.getText().toString());
                }

                EditText editText3=(EditText) findViewById(R.id.edittext_3);
                String ans3 = editText3.getText().toString();
                String rightAns3 = new StackCalculate(finalNumRange).getResult(textView3.getText().toString());
                if(ans3.equals(rightAns3))
                    right++;
                if(!ans3.equals(rightAns3)){
                    wrong++;
                    args[t]=(String) textView3.getText();
                    t++;
                    StoreQuestion.addToWrongFile(MainActivity2.this,textView3.getText().toString());
                }

                EditText editText4=(EditText) findViewById(R.id.edittext_4);
                String ans4 = editText4.getText().toString();
                String rightAns4 = new StackCalculate(finalNumRange).getResult(textView4.getText().toString());
                if(ans4.equals(rightAns4))
                    right++;
                if(!ans4.equals(rightAns4)){
                    wrong++;
                    args[t]=(String) textView4.getText();
                    t++;
                    StoreQuestion.addToWrongFile(MainActivity2.this,textView4.getText().toString());
                }

                EditText editText5=(EditText) findViewById(R.id.edittext_5);
                String ans5 = editText5.getText().toString();
                String rightAns5 = new StackCalculate(finalNumRange).getResult(textView5.getText().toString());
                if(ans5.equals(rightAns5))
                    right++;
                if(!ans5.equals(rightAns5)){
                    wrong++;
                    args[t]=(String) textView5.getText();
                    t++;
                    StoreQuestion.addToWrongFile(MainActivity2.this,textView5.getText().toString());
                }

                Intent intent1 = new Intent(MainActivity2.this, MainActivity3.class);
                Bundle bundle = new Bundle();
                bundle.putInt("wrong",wrong);
                bundle.putInt("right",right);
                bundle.putInt("second",timeend);
                bundle.putInt("second1",second);
                bundle.putStringArray("args1",args);
                intent1.putExtras(bundle);
                startActivity(intent1);
            }
        });




        while (true) {
            CalculateSystem x = new CalculateSystem(spinner,0);
            String formula1 = x.createOneExercise(finalNumRange);

            if (new StackCalculate(finalNumRange).getResult(formula1).equals("-1")) continue;
            if(i>number)
                break;
            textView1.setText(String.valueOf(formula1));
            i++;
            break;
        }


        while (true) {
            CalculateSystem x = new CalculateSystem(spinner,0);
            String formula2 = x.createOneExercise(finalNumRange);

            if (new StackCalculate(finalNumRange).getResult(formula2).equals("-1")) continue;
            if(i>number)
                break;
            textView2.setText(String.valueOf(formula2));
            i++;
            break;

        }
        while (true) {
            CalculateSystem x = new CalculateSystem(spinner,0);
            String formula3 = x.createOneExercise(finalNumRange);

            if (new StackCalculate(finalNumRange).getResult(formula3).equals("-1")) continue;
            if(i>number)
               break;
            textView3.setText(String.valueOf(formula3));
            i++;
            break;
        }
        while (true) {
            CalculateSystem x = new CalculateSystem(spinner,0);
            String formula4 = x.createOneExercise(finalNumRange);

            if (new StackCalculate(finalNumRange).getResult(formula4).equals("-1")) continue;
            if(i>number)
                break;
            textView4.setText(String.valueOf(formula4));
            i++;
            break;
        }
        while (true) {
            CalculateSystem x = new CalculateSystem(spinner,0);
            String formula5 = x.createOneExercise(finalNumRange);

            if (new StackCalculate(finalNumRange).getResult(formula5).equals("-1")) continue;
            if(i>number)
               break;
            textView5.setText(String.valueOf(formula5));
            i++;
            break;
        }




        imageButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

    EditText editText1 = (EditText) findViewById(R.id.edittext_1);
    //String rightAns = new StackCalculate(finalNumRange).getResult(textView1.getText().toString());
if(second!=0) {
    String ans = editText1.getText().toString();
    String rightAns = new StackCalculate(finalNumRange).getResult(textView1.getText().toString());


    if (i <= number) {
        if (!ans.equals(rightAns)) {
            wrong++;
            args[t] = (String) textView1.getText();
            t++;
            StoreQuestion.addToWrongFile(MainActivity2.this,textView1.getText().toString());
        }
        if (ans.equals(rightAns))
            right++;
    }
}

                while (true) {
                    CalculateSystem x = new CalculateSystem(spinner,0);
                    String formula1 = x.createOneExercise(finalNumRange);
                    if(second==0) {
                        Toast.makeText(MainActivity2.this, "时间到了", Toast.LENGTH_LONG).show();
                        break;
                    }
                    if(i>number)
                    {
                        Toast.makeText(MainActivity2.this,"已经是最后一题了",Toast.LENGTH_LONG).show();
                    /*    regular=wrong ;
                        if(!ans.equals(rightAns))
                            regular--;
                        if(ans.equals(rightAns))
                         */  // regular++;
                        break;
                    }
                    else editText1.setText(null);


                    if (new StackCalculate(finalNumRange).getResult(formula1).equals("-1")) continue;

                    textView1.setText(String.valueOf(formula1));
                    i++;
                    break;
                }

            }
        });

        imageButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText editText1=(EditText) findViewById(R.id.edittext_2);
                if(second!=0) {
                    String ans = editText1.getText().toString();
                    String rightAns = new StackCalculate(finalNumRange).getResult(textView2.getText().toString());
                    if (i <= number) {
                        if (!ans.equals(rightAns)) {
                            wrong++;
                            args[t] = (String) textView2.getText();
                            t++;
                            StoreQuestion.addToWrongFile(MainActivity2.this,textView2.getText().toString());
                        }
                        if (ans.equals(rightAns))
                            right++;
                    }
                }
                while (true) {
                    CalculateSystem x = new CalculateSystem(spinner,0);
                    String formula2 = x.createOneExercise(finalNumRange);
                    if(second==0) {
                        Toast.makeText(MainActivity2.this, "时间到了", Toast.LENGTH_LONG).show();
                        break;
                    }
                    if(i>number)
                    {
                        Toast.makeText(MainActivity2.this,"已经是最后一题了",Toast.LENGTH_LONG).show();

                      /*  regular=wrong ;

                        if(!ans.equals(rightAns))
                            regular--;

                            if(ans.equals(rightAns))
                        */        regular++;
                            break;
                    }

                    else editText1.setText(null);
                    if (new StackCalculate(finalNumRange).getResult(formula2).equals("-1")) continue;

                    textView2.setText(String.valueOf(formula2));
                    i++;
                    break;
                }

            }
        });

        imageButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText editText1=(EditText) findViewById(R.id.edittext_3);
                if(second!=0){
                String ans = editText1.getText().toString();
                String rightAns = new StackCalculate(finalNumRange).getResult(textView3.getText().toString());

                if(i<=number) {
                    if (!ans.equals(rightAns)) {
                        wrong++;
                        args[t] = (String) textView3.getText();
                        t++;
                        StoreQuestion.addToWrongFile(MainActivity2.this,textView3.getText().toString());
                    }
                    if (ans.equals(rightAns))
                        right++;
                }}
                while (true) {
                    CalculateSystem x = new CalculateSystem(spinner,0);
                    String formula3 = x.createOneExercise(finalNumRange);
                    if(second==0) {
                        Toast.makeText(MainActivity2.this, "时间到了", Toast.LENGTH_LONG).show();
                        break;
                    }
                    if(i>number)
                    {
                        Toast.makeText(MainActivity2.this,"已经是最后一题了",Toast.LENGTH_LONG).show();

                     /*   regular=wrong ;

                        if(!ans.equals(rightAns))
                            regular--;

                            if(ans.equals(rightAns))
                      */          regular++;
                            break;
                    }
                    else editText1.setText(null);
                    if (new StackCalculate(finalNumRange).getResult(formula3).equals("-1")) continue;

                    textView3.setText(String.valueOf(formula3));
                    i++;
                    break;
                }

            }
        });


        imageButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText editText1=(EditText) findViewById(R.id.edittext_4);
                if(second!=0){
                String ans = editText1.getText().toString();
                String rightAns = new StackCalculate(finalNumRange).getResult(textView4.getText().toString());

                if(i<=number){
                    if(!ans.equals(rightAns)) {
                        wrong++;
                        args[t] = (String) textView4.getText();
                        t++;
                        StoreQuestion.addToWrongFile(MainActivity2.this,textView4.getText().toString());
                    }
                    if(ans.equals(rightAns))
                        right++;}}
                while (true) {
                    CalculateSystem x = new CalculateSystem(spinner,0);
                    String formula4 = x.createOneExercise(finalNumRange);
                    if(second==0) {
                        Toast.makeText(MainActivity2.this, "时间到了", Toast.LENGTH_LONG).show();
                        break;
                    }
                    if(i>number)
                    {
                        Toast.makeText(MainActivity2.this,"已经是最后一题了",Toast.LENGTH_LONG).show();
                      /*  regular=wrong ;

                        if(!ans.equals(rightAns))
                            regular--;

                            if(ans.equals(rightAns))
                          */      regular++;
                            break;
                    }
                    else editText1.setText(null);
                    if (new StackCalculate(finalNumRange).getResult(formula4).equals("-1")) continue;

                    textView4.setText(String.valueOf(formula4));
                    i++;
                    break;
                }

            }
        });

        imageButton5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText editText1=(EditText) findViewById(R.id.edittext_5);
                if(second!=0){
                String ans = editText1.getText().toString();
                String rightAns = new StackCalculate(finalNumRange).getResult(textView5.getText().toString());

                if(i<=number){
                    if(!ans.equals(rightAns)) {
                        wrong++;
                        args[t] = (String) textView5.getText();
                        t++;
                        StoreQuestion.addToWrongFile(MainActivity2.this,textView5.getText().toString());
                    }
                    if(ans.equals(rightAns))
                        right++;}}
                while (true) {
                    CalculateSystem x = new CalculateSystem(spinner,0);
                    String formula5 = x.createOneExercise(finalNumRange);
                    if(second==0) {
                        Toast.makeText(MainActivity2.this, "时间到了", Toast.LENGTH_LONG).show();
                        break;
                    }
                    if(i>number)
                    {
                        Toast.makeText(MainActivity2.this,"已经是最后一题了"+wrong,Toast.LENGTH_LONG).show();
                     /*   regular=wrong ;

                        if(!ans.equals(rightAns))
                            regular--;

                            if(ans.equals(rightAns))
                           */     regular++;
                            break;
                    }
                    else editText1.setText(null);
                    if (new StackCalculate(finalNumRange).getResult(formula5).equals("-1")) continue;

                    textView5.setText(String.valueOf(formula5));
                    i++;
                    break;
                }

            }

        });







    }
}