package com.example.xhxt;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

public class maypage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maypage);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar!=null){
            actionBar.hide();
        }
        ImageButton button_1=( ImageButton ) findViewById(R.id.backto1);
        ImageButton  button_2=( ImageButton ) findViewById(R.id.backto2);
        ImageButton  button_3=(ImageButton) findViewById(R.id.wrongPractice);
        ImageButton  button_4=(ImageButton) findViewById(R.id.favourSet);
        ImageButton wrong1 = findViewById(R.id.wrong1);
        button_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(maypage.this,shoucangjia.class);
                startActivity(intent);
            }
        });
        wrong1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(maypage.this, WrongSetActivity.class);
                startActivity(intent);
            }
        });


        button_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(maypage.this,MainActivity.class);
                startActivity(intent);
            }
        });
        button_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(maypage.this,maypage.class);
                startActivity(intent);
            }
        });
        button_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(StoreQuestion.GetWrongQuestionNum(maypage.this)==0){
                    Toast.makeText(maypage.this, "目前没有错题", Toast.LENGTH_SHORT).show();

                }
                else{
                    Intent intent=new Intent(maypage.this,WrongTest.class);
                    startActivity(intent);
                }

            }
        });


    }
}