package com.example.xhxt;

import android.content.Context;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashSet;

public class StoreQuestion {

    /*添加错题到文件中
    * 每一次添加都会与原文件中所有内容依次比较，保证题目不重复
    * 通过牺牲时间换取了查重功能 。与快捷的删除错题功能
    */
     static public void addToWrongFile(Context context,String question){
        //wrongSet.add(question);
       // addToWrongSet(question);
        File fileDir =context.getFilesDir();
        File saveFile =new File(fileDir,"wrongset.txt");
      try{
            if (!saveFile.exists()){
                saveFile.createNewFile();
            }
             FileInputStream fileInputStream =context.openFileInput("wrongset.txt");
             BufferedReader bufferedReader =new BufferedReader(new InputStreamReader(fileInputStream));
             String line;
             boolean hasEqual=false;
             while ((line = bufferedReader.readLine()) != null) {
                if(line.equals(question)){
                    hasEqual=true;
                    break;
                }
            }
             FileOutputStream fos =new FileOutputStream(saveFile,true);
             if(!hasEqual) fos.write((question+"\n").getBytes());
             fos.close();
        } catch (Exception e){
            e.printStackTrace();
        }
    }
    /*添加收藏题目到文件中
     * 每一次添加都会与原文件中所有内容依次比较，保证题目不重复
     * 通过牺牲时间换取了查重功能。
     */
    static public void addToFavourFile(Context context,String question){
        File fileDir =context.getFilesDir();
        File saveFile =new File(fileDir,"favourset.txt");
        try{
            if (!saveFile.exists()){
                saveFile.createNewFile();
            }
            boolean hasEqual=false;
            FileInputStream fileInputStream =context.openFileInput("favourset.txt");
            BufferedReader bufferedReader =new BufferedReader(new InputStreamReader(fileInputStream));
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                if(line.equals(question)){
                    hasEqual=true;
                    Toast.makeText(context,"本题已在收藏夹内",Toast.LENGTH_SHORT).show();
                    break;
                }
            }
            FileOutputStream fos =new FileOutputStream(saveFile,true);
            if(!hasEqual){
                fos.write((question+"\n").getBytes());
                Toast.makeText(context,"添加成功",Toast.LENGTH_SHORT).show();
            }
            fos.close();

        } catch (Exception e){
            e.printStackTrace();
        }
    }
    /*返回值为String类型数组，数组中的每一个字符串代表一道错题
    * 可以调用GetWrongQuestionNum函数得到错题数量
    * */
     public static String[] GetWrongQuestion(Context context){
         int wrongNum=GetWrongQuestionNum(context);
         String[] wrongSet =new String[wrongNum];
         try {
             FileInputStream fileInputStream =context.openFileInput("wrongset.txt");
             BufferedReader bufferedReader =new BufferedReader(new InputStreamReader(fileInputStream));
             String line;int i=0;
             while ((line = bufferedReader.readLine()) != null) {
                 wrongSet[i]=line;
                 i++;
             }
             return wrongSet;
         } catch (Exception e) {
             e.printStackTrace();
             //return wrongSet;
             return null;
         }
     }
     /*返回值为int,代表错题数量
     * */
     static public int GetWrongQuestionNum(Context context){
         int i=0;
         try {
             FileInputStream fileInputStream =context.openFileInput("wrongset.txt");
             BufferedReader bufferedReader =new BufferedReader(new InputStreamReader(fileInputStream));
             String line;
             while ((line = bufferedReader.readLine()) != null) {
                 i++;
             }
             return i;
         } catch (Exception e) {
             e.printStackTrace();
             return i;
         }
     }
    /*返回值为String类型数组，数组中的每一个字符串代表一道题目
     * 可以调用GetFavourQuestionNum函数得到收藏夹题目数量
     * */
    static public String[] GetFavourQuestion(Context context){
        int favourNum=GetFavourQuestionNum(context);
        String[] favourSet =new String[favourNum];
        try {
            FileInputStream fileInputStream =context.openFileInput("favourset.txt");
            BufferedReader bufferedReader =new BufferedReader(new InputStreamReader(fileInputStream));
            String line;int i=0;
            while ((line = bufferedReader.readLine()) != null) {
                favourSet[i]=line;
                i++;
            }
            return favourSet;
        } catch (Exception e) {
            e.printStackTrace();
            return favourSet;
        }
    }
    /*返回值为int,代表收藏夹中题目数量
     * */
    static public int GetFavourQuestionNum(Context context){
        int i=0;
        try {
            FileInputStream fileInputStream =context.openFileInput("favourset.txt");
            BufferedReader bufferedReader =new BufferedReader(new InputStreamReader(fileInputStream));
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                i++;
            }
            return i;
        } catch (Exception e) {
            e.printStackTrace();
            return i;
        }
    }
     /*使用LinkedHashSet作为删除操作时的转化媒介
     *同时调用两个已有函数对文件进行更新
     * */
     static public void RemoveWrongQuestion(Context context,String question){
          LinkedHashSet<String> wrongSet=new LinkedHashSet<>(Arrays.asList(GetWrongQuestion(context)));
          wrongSet.remove(question);
          for (String que : wrongSet) {
              addToWrongFile(context,que);
          }
     }
    /*使用LinkedHashSet作为删除操作时的转化媒介
     *同时调用两个已有函数对文件进行更新
     * */
    static public void RemoveFavourQuestion(Context context,String question){
        LinkedHashSet<String> favourSet=new LinkedHashSet<>(Arrays.asList(GetFavourQuestion(context)));
        favourSet.remove(question);
        for (String que : favourSet) {
            addToFavourFile(context,que);
        }
    }
    /*清空所有错题文件
    * */
     static public void RemoveAllWrongQuestion(Context context){
         File fileDir =context.getFilesDir();
         File saveFile =new File(fileDir,"wrongset.txt");
         try{
             if (!saveFile.exists()){
                 saveFile.createNewFile();
             }
             FileOutputStream fos =new FileOutputStream(saveFile);
             fos.close();
             Toast.makeText(context,"全部清除成功",Toast.LENGTH_SHORT).show();
         } catch (Exception e){
             e.printStackTrace();
         }
     }
    /*清空所有收藏夹文件
     * */
    static public void RemoveAllFavourQuestion(Context context){
        File fileDir =context.getFilesDir();
        File saveFile =new File(fileDir,"favourset.txt");
        try{
            if (!saveFile.exists()){
                saveFile.createNewFile();
            }
            FileOutputStream fos =new FileOutputStream(saveFile);
            fos.close();
            Toast.makeText(context,"全部清除成功",Toast.LENGTH_SHORT).show();
        } catch (Exception e){
            e.printStackTrace();
        }
    }
}



