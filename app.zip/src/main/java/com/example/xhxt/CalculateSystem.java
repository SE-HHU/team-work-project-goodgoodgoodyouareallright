package com.example.xhxt;
import java.io.FileWriter;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Random;

public class CalculateSystem {
    class TypeNumber
    {
        boolean numberType;
        public TypeNumber()
        {
            if(grade==1||grade==2||grade==3||grade==4||sp==1||sp==2||sp==3||sp==4)
                this.numberType=true;
            if(sp==6)
                this.numberType=false;
            else
                this.numberType = new Random().nextBoolean();
        }
        public String getTNumber(int numRange)
        {
            CalculateSystem a = new CalculateSystem();
            if (numberType)
            {
                return a.getNumber(numRange);
            }
            else
            {
                return a.getNumber(numRange)+"/"+a.getNumber(numRange);
            }
        }
    }
    int grade;  int sp;
    public CalculateSystem()//构造方法
    {

    }
   public CalculateSystem(int grade)//构造方法
    {
        this.grade=grade;
    }
    public CalculateSystem(int sp,int sp2)//构造方法
    {
        this.sp=sp;
    }

    /*
     * function:       //createOneExercise
     * Description:    //生成一道题目
     * Calls:          //getSignNumber();getSignNumber();getNumber();hasBrackets()
     * Calls By:       //produceFiles();
     */
    String createOneExercise(int numRange)
    {
        //生成一道不带括号的题目;
        LinkedList<Object> list = new LinkedList<>();
        int signNumber = getSignNumber();
        if(grade==1||grade==2||grade==3||grade==4||sp==1||sp==2||sp==3||sp==4)
            list.add(getNumber(numRange));
        else
            list.add(new TypeNumber().getTNumber(numRange));
      //  list.add(new TypeNumber().getTNumber(numRange));
        for(int i =0;i<signNumber;i++)
        {
            list.add(getSign());

            if(grade==1||grade==2||grade==3||grade==4||sp==1||sp==2||sp==3||sp==4)
                list.add(getNumber(numRange));
            else
                list.add(new TypeNumber().getTNumber(numRange));
        }
        //在不带括号的基础上加入括号；
        if (signNumber >= 2&&hasBrackets())
        {
            //在链表不同位置加入括号
            if(signNumber == 2)
            {
                if(!new Random().nextBoolean())
                {
                    list.add(0,"(");
                    list.add(4,")");
                }
                else
                {
                    list.add(2,"(");
                    list.add(6,")");
                }
            }
            if(signNumber == 3)
            {
                switch ((int) (Math.random() * 6) + 1) {
                    case 1 : {
                        list.add(0, "(");
                        list.add(4, ")");
                        break;
                    }
                    case 2 : {
                        list.add(2, "(");
                        list.add(6, ")");
                        break;
                    }
                    case 3 : {
                        list.add(4, "(");
                        list.add(8, ")");
                        break;
                    }
                    case 4 : {
                        list.add(0, "(");
                        list.add(4, ")");
                        list.add(6, "(");
                        list.add(10, ")");
                        break;
                    }
                    case 5 : {
                        list.add(0, "(");
                        list.add(6, ")");
                        break;
                    }
                    case 6 : {
                        list.add(2, "(");
                        list.add(8, ")");
                        break;
                    }
                }
            }

        }
        //将链表中元素遍历，形成字符串
        ListIterator<Object> it = list.listIterator();
        StringBuilder in = new StringBuilder();
        while (it.hasNext())
        {
            Object next = it.next();
            if (next instanceof String)
                in.append(next);
            else
            {
                TypeNumber t = (TypeNumber) next;
                in.append(t.getTNumber(numRange));
            }
        }
        return in.toString();
    }


    //产生一个范围内的整数
    String getNumber(int numRange)
    {

        return String.valueOf((int)(Math.random() * (numRange)) + 1);
    }
    //随机生成1到3个运算符个数
    int getSignNumber()
    {
        if(grade==1||sp==1||sp==2)
            return 1;
        if(grade==2) {
            if (hasBrackets())
            return 2;
        else
            return 1;
        }
        if(sp==3||sp==6)
            return 2;
        return (int)(Math.random() * 3) + 1;

    }
    //用1，2，3，4来代表"+""-""*""➗"
    String getSign()
    {

        int temp;
        if(grade==1||grade==2||sp==1||sp==2) temp=(int) (Math.random() * 2) + 1;
        else if(grade==3||sp==4) temp=(int) (Math.random() * 3) + 1;
        else if(sp==3)
            temp=3;
        else if(sp==6)
            temp=4;
        else
            temp=(int) (Math.random() * 4) + 1;
         switch (temp) {
            case 1 : return "+";
            case 2 : return "-";
            case 3 : return "×";
            case 4 : return "÷";
            default :return "";
        }
    }
    //随机确定是否有括号；
    boolean hasBrackets()
    {
        if(grade==1||grade==2||sp==1||sp==2||sp==3||sp==6)
            return false;
        return !new Random().nextBoolean();
    }
}

