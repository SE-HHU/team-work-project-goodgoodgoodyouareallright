package com.example.xhxt;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class ending extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ending);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar!=null){
            actionBar.hide();
        }
        Intent intent =getIntent();
        Bundle bundle=intent.getExtras();
        String [] args = bundle.getStringArray("args1");
        int wrong = bundle.getInt("wrong");

        TextView t= (TextView) findViewById(R.id.ttee);
        TextView t1= (TextView) findViewById(R.id.ts1);
        t.setTextSize(30);
        t.setText("错:"+wrong+"题");

        t1.setTextSize(30);
         for(int i=0;i<wrong;i++){
        t1.append((i+1)+".  ");
            t1.append(args[i]+"="+"\n");
        }

        ImageButton button=(ImageButton) findViewById(R.id.backtopage);
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent=new Intent(ending.this,MainActivity.class);
                    startActivity(intent);
                    }
                });

    }
}