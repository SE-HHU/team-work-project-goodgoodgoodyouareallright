package com.example.xhxt;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class select_level extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.select_level);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar!=null){
            actionBar.hide();
        }
        Intent intent1 = getIntent();
        Bundle bundle=intent1.getExtras();
        int function = bundle.getInt("function");
       // int function = intent1.getIntExtra("function",1);
        ImageButton level_1 = findViewById(R.id.level1);
        ImageButton level_2 = findViewById(R.id.level2);
        ImageButton level_3 = findViewById(R.id.level3);
        ImageButton level_4 = findViewById(R.id.level4);
        ImageButton level_5 = findViewById(R.id.level5);
        ImageButton level_6 = findViewById(R.id.level6);

        level_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //切换页面逻辑 单体测试
                Intent intent = null;
                switch (function){
                    case 1:
                        intent = new Intent(select_level.this,MainActivity1.class);
                        break;
                    case 2:
                        //intent = new Intent(Second_Activity.this,MainActivity1.class);
                        intent = new Intent(select_level.this, edit_text1.class);
                }
                //if(function==1)  intent = new Intent(Second_Activity.this,MainActivity1.class);

               // else intent =  new Intent(Second_Activity.this,Third_Activity.class);
                intent.putExtra("grade",1);
                startActivity(intent);
            }
        });

        level_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //切换页面逻辑 单体测试
                Intent intent = null;
                switch (function){
                    case 1:
                        intent = new Intent(select_level.this,MainActivity1.class);
                        break;
                    case 2:
                        intent = new Intent(select_level.this, edit_text1.class);
                }
                intent.putExtra("grade",2);
                startActivity(intent);
            }
        });

        level_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //切换页面逻辑 单体测试
                Intent intent = null;
                switch (function){
                    case 1:
                        intent = new Intent(select_level.this,MainActivity1.class);
                        break;
                    case 2:
                        intent = new Intent(select_level.this, edit_text1.class);
                }
                intent.putExtra("grade",3);
                startActivity(intent);
            }
        });

        level_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //切换页面逻辑 单体测试
                Intent intent = null;
                switch (function){
                    case 1:
                        intent = new Intent(select_level.this,MainActivity1.class);
                        break;
                    case 2:
                        intent = new Intent(select_level.this, edit_text1.class);
                }
                intent.putExtra("grade",4);
                startActivity(intent);
            }
        });

        level_5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //切换页面逻辑 单体测试
                Intent intent = null;
                switch (function){
                    case 1:
                        intent = new Intent(select_level.this,MainActivity1.class);
                        break;
                    case 2:
                        intent = new Intent(select_level.this, edit_text1.class);
                }
                intent.putExtra("grade",5);
                startActivity(intent);
            }
        });

        level_6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //切换页面逻辑 单体测试
                Intent intent = null;
                switch (function){
                    case 1:
                        intent = new Intent(select_level.this,MainActivity1.class);
                        break;
                    case 2:
                        intent = new Intent(select_level.this, edit_text1.class);
                }
                intent.putExtra("grade",6);
                startActivity(intent);
            }
        });

    }
}
