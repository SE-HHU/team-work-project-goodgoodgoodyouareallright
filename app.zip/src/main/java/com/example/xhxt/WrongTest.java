package com.example.xhxt;

import android.content.Intent;
import android.os.Bundle;
import android.view.TouchDelegate;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class WrongTest extends AppCompatActivity {
    int right=0;
    int wrong=0;
    int number=0;
    boolean boo=true;
    boolean boo1=false;
    String [] last=new String[10000];
   // String [] wrongQuestion=new String[]{"1+1","2+2"};
    String [] wrongQuestion;
    //ArrayList<String> wrongQuestion =new ArrayList<String>();

    int last_1=0;
    int i=0;
    String []  wrongnumber = new String[10000];
    int num=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main1);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar!=null){
            actionBar.hide();
        }

        wrongQuestion=StoreQuestion.GetWrongQuestion(WrongTest.this);
        TextView textView1 = (TextView) findViewById(R.id.textView2);
        ImageButton button1 = (ImageButton) findViewById(R.id.button_1);
        TextView textView11=(TextView) findViewById(R.id.textview1);
        TextView textView22=(TextView) findViewById(R.id.textview2);
        TextView textView33=(TextView) findViewById(R.id.textview3);
        //Intent intent =getIntent();
        //int grade = intent.getIntExtra("grade",1);
        int grade=6;
        int numRange=100 ;
        //int grade =3;
        if(grade==1) numRange=10;
        if(grade==2) numRange=20;
        if(grade==3) numRange=30;
        if(grade==4) numRange=50;
        if(grade==5) numRange=60;
        if(grade==6) numRange=80;
        int finalNumRange = numRange;

        ImageButton button10=(ImageButton) findViewById(R.id.buttonc);
        ImageButton button9=(ImageButton) findViewById(R.id.button__1);




         String formula = wrongQuestion[num++];


            textView1.setText(String.valueOf(formula));

            last[last_1]=formula;
            last_1++;

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(WrongTest.this);
                builder.setMessage("答案是："+new StackCalculate(finalNumRange).getResult(textView1.getText().toString()));
                builder.setPositiveButton("确定", null).show();

            }
        });
        ImageButton button2 = (ImageButton) findViewById(R.id.button_2);

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(num==StoreQuestion.GetWrongQuestionNum(WrongTest.this)){
                    Toast.makeText(WrongTest.this,"这是最后一道错题了",Toast.LENGTH_SHORT).show();;
                    return;
                }
                if(i==last_1-1){
                    EditText editText = (EditText) findViewById(R.id.editText);
                    String ans = editText.getText().toString();
                    String rightAns = new StackCalculate(finalNumRange).getResult(textView1.getText().toString());


                    if (ans.equals(String.valueOf(rightAns))) {
                        if(boo){
                            number++;
                            right++;
                            textView11.setText("答题："+number+"题");
                            textView22.setText("答对："+right+"题");
                        }
                        boo=true;boo1=false;


                        Toast.makeText(WrongTest.this, "回答正确", Toast.LENGTH_LONG).show();
                            String formula = wrongQuestion[num++];
                            textView1.setText(String.valueOf(formula));
                            last[last_1]=formula;
                            last_1++;
                            i++;

                        editText.setText(null);
                    }
                    else {
                        editText.setText(null);
                        if(!boo1){
                            wrongnumber[wrong]=textView1.getText().toString();
                            wrong++;
                            number++;
                            textView11.setText("答题："+number+"题");
                            textView33.setText("答错："+wrong+"题");
                            boo1=true;
                        }
                        boo=false;

                        Toast.makeText(WrongTest.this,"错误，请重新输入",Toast.LENGTH_LONG).show();
                        // Toast.makeText(MainActivity.this, rightAns, Toast.LENGTH_LONG).show();
                    }
                }
                if(i!=last_1-1)
                {

                    textView1.setText(String.valueOf(last[i]));
                    EditText editText9 = (EditText) findViewById(R.id.editText);
                    String ans1 = editText9.getText().toString();
                    String rightAns1 = new StackCalculate(finalNumRange).getResult(textView1.getText().toString());
                    if (ans1.equals(String.valueOf(rightAns1)))
                    {
                        i++;
                        Toast.makeText(WrongTest.this, "回答正确", Toast.LENGTH_LONG).show();
                        StoreQuestion.RemoveWrongQuestion(WrongTest.this,textView1.getText().toString());
                        editText9.setText(null);
                        textView1.setText(String.valueOf(last[i]));
                    }
                    else
                    {
                        editText9.setText(null);
                        Toast.makeText(WrongTest.this,"错误，请重新输入",Toast.LENGTH_LONG).show();
                        StoreQuestion.addToWrongFile(WrongTest.this,textView1.getText().toString());

                    }

                }

            }
        });


        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(i>0) {
                    textView1.setText(String.valueOf(last[i-1]));
                    i--;
                    //  Toast.makeText(MainActivity1.this," "+i,Toast.LENGTH_LONG).show();
                }
                else  if(i==0)
                    Toast.makeText(WrongTest.this,"这是第一题",Toast.LENGTH_LONG).show();
            }
        });
        button10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(WrongTest.this, ending.class);
                Bundle bundle = new Bundle();
                bundle.putInt("wrong",wrong);
                bundle.putStringArray("args1",wrongnumber);
                intent1.putExtras(bundle);
                startActivity(intent1);
            }
        });

    }
}
