package com.example.xhxt;

import android.content.Intent;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import org.w3c.dom.Document;

public class edit_text1 extends AppCompatActivity {
    int t=0;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_text1);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar!=null){
            actionBar.hide();
        }


        Spinner spinner=(Spinner) findViewById(R.id.spinner1);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
              String result2 = parent.getItemAtPosition(position).toString();
              if(result2.equals("十以内加减法"))
                    t=1;
                if(result2.equals("两位数加减法"))
                    t=2;
                if(result2.equals("简单数的连乘法"))
                    t=3;
                if(result2.equals("简单数的加减乘法"))
                    t=4;
                if(result2.equals("四则运算"))
                    t=5;
                if(result2.equals("分数的连除法"))
                    t=6;
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });



        ImageButton printer = findViewById(R.id.print1);
        ImageButton starter = findViewById(R.id.start1);
        Intent intent1 = getIntent();
        int grade = intent1.getIntExtra("grade",1);
        //int grade =1;

        starter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(edit_text1.this,MainActivity2.class);
                EditText editText1 = findViewById(R.id.editText100);
                EditText editText =findViewById(R.id.time);
                int number =20;
                int time=600;
                if (!TextUtils.isEmpty(editText1.getText()))
                    number = Integer.valueOf(editText1.getText().toString()).intValue();
                if (!TextUtils.isEmpty(editText.getText()))
                    time = Integer.valueOf(editText.getText().toString()).intValue();
                intent.putExtra("time",time);
                intent.putExtra("number",number);
                intent.putExtra("grade",grade);
                intent.putExtra("spinner", t);
                startActivity(intent);

            }
        });


        printer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            //

                Toast.makeText(edit_text1.this, "该功能尚处于开发中"+t, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
