package com.example.xhxt;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

class Formula {
    String name;
    int imageId;
    public Formula(String name, int imageId){
        this.name = name;
        this.imageId = imageId;
    }
}


public class WrongSetActivity extends AppCompatActivity {

    private List<Formula> wrongList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wrong_set);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar!=null){
            actionBar.hide();
        }
       String [] wrongSet = StoreQuestion.GetWrongQuestion(WrongSetActivity.this);

        init(wrongSet);
        FruitAdapter adapter = new FruitAdapter(WrongSetActivity.this, R.layout.tab, wrongList);
        ListView listView = (ListView) findViewById(R.id.list_view);
        listView.setAdapter(adapter);
    }
    private void init(String[] wrongSet){

        for (int i =0; i<wrongSet.length;i++){
            wrongList.add(new Formula(wrongSet[i]+"  答案："+new StackCalculate(100).getResult(wrongSet[i]),R.drawable.da));
        }





    }
}