package com.example.xhxt;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar!=null){
            actionBar.hide();
        }
        Intent intent =getIntent();
        Bundle bundle=intent.getExtras();
        int second = bundle.getInt("second");
        int wrong = bundle.getInt("wrong");
        int right = bundle.getInt("right");
        int second1=bundle.getInt("second1");
        int second2=second-second1;
        String [] args = bundle.getStringArray("args1");
        TextView tv3=(TextView) findViewById(R.id.text);
        TextView tv4=(TextView) findViewById(R.id.timeuse);
        TextView tv5=(TextView) findViewById(R.id.wrongnumber);
        tv3.setTextSize(10);
        tv4.setText(second2+"秒");
        tv5.setText(wrong+"");


        //tv3.setText("                                "+second2+"秒"+"\n"+"\n"
       //         +"                                "+wrong+"\n");
        //   tv3.append("123");
        tv3.setTextSize(20);
        for(int i=1;i<=wrong;i++){
            tv3.append(i+".  ");
            tv3.append(args[i]+"="+"\n");
            tv3.append("答案："+new StackCalculate(1000).getResult(args[i])+"\n");
        }
        ImageButton pjj = findViewById(R.id.pjj);
        pjj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity3.this,MainActivity.class);
                startActivity(intent);
            }
        });
    }
}